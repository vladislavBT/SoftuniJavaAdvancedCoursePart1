package JavaAdvancedDefineClassExercise.P04RawData;

public class Tires {
    double tyre1Pressure;
    int tyre1Age;
    double tyre2Pressure;
    int tyre2Age;
    double tyre3Pressure;
    int tyre3Age;
    double tyre4Pressure;
    int tyre4Age;

    public Tires(double tyre1Pressure, int tyre1Age, double tyre2Pressure, int tyre2Age, double tyre3Pressure, int tyre3Age, double tyre4Pressure, int tyre4Age) {
        this.tyre1Pressure=tyre1Pressure;
        this.tyre1Age=tyre1Age;
        this.tyre2Pressure=tyre1Pressure;
        this.tyre2Age=tyre1Age;
        this.tyre3Pressure=tyre1Pressure;
        this.tyre3Age=tyre1Age;
        this.tyre4Pressure=tyre1Pressure;
        this.tyre4Age=tyre1Age;

    }
}
