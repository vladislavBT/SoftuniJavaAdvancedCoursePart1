package JavaAdvancedDefineClassExercise.P04RawData;

public class Car {
    String model;
    Engine engineOfCar;
    Cargo cargoOfCar;
    Tires tiresOfCar;

    public Car(String model, Engine engineOfCar, Cargo cargoOfCar, Tires tiresOfCar) {
        this.model = model;
        this.engineOfCar = engineOfCar;
        this.cargoOfCar = cargoOfCar;
        this.tiresOfCar = tiresOfCar;
    }
}
