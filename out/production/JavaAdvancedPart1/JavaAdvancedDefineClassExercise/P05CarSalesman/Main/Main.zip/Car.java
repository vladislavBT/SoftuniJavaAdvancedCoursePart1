package JavaAdvancedDefineClassExercise.P05CarSalesman.Main;

public class Car {

    String model;
    Engine engine;
    String weight;
    String color;

    public Car(String model, Engine engine, String weight, String color) {
        this.model = model;
        this.engine = engine;
        this.weight = weight;
        this.color = color;
    }
}
